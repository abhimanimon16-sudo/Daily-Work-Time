Daily Work Time — Android project

এই ZIP-এ Android Studio-তে খোলা ও APK build করার মতো project source আছে।
এটি এখনো তৈরি করা APK ফাইল নয়; APK বানাতে Android Studio ব্যবহার করতে হবে।

APK তৈরির ধাপ:
1. কম্পিউটারে Android Studio ইনস্টল করুন।
2. ZIP ফাইলটি Extract করুন।
3. Android Studio খুলে Open নির্বাচন করে DailyWorkTime ফোল্ডারটি খুলুন।
4. Gradle sync শেষ হওয়া পর্যন্ত অপেক্ষা করুন।
5. Build > Build Bundle(s) / APK(s) > Build APK(s) নির্বাচন করুন।
6. Build সফল হলে সাধারণত app/build/outputs/apk/debug/app-debug.apk ফাইল পাওয়া যাবে।
7. APK ফোনে কপি করে খুলুন। ফোন চাইলে এই উৎস থেকে app install করার অনুমতি দিন।

গুরুত্বপূর্ণ:
- এই অ্যাপ অফলাইনে চলে এবং কাজের রেকর্ড ফোনের অ্যাপের স্থানীয় storage-এ রাখে।
- অ্যাপের data clear বা app uninstall করলে রেকর্ড মুছে যেতে পারে।
- অ্যাপের Work History থেকে নিয়মিত Export CSV করে backup রাখুন।
- Build করার জন্য Android Studio-সহ একটি কম্পিউটার প্রয়োজন। শুধু Android ফোন দিয়ে এই project ZIP-কে সরাসরি APK-তে পরিণত করা যায় না।
